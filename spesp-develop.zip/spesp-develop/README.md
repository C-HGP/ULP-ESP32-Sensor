| PIN        | PIN ROW           | PIN  |
| ------------- |:-------------:| -----:|  
|              [VIN 3v3]         | 1 |   GND                 |  
|              RESET             |2|   GPIO23 [VPSIMOSI]   |  
|              GPIO36            |3|   GPIO22              |  
|              GPIO39            |4|   GPIO1 [TX0]         |  
|              GPIO34            |5|   GPIO3 [RX0]         |  
|              GPIO35            |6|   GPIO21              |  
|              GPIO32            |7|   GND                 |  
|              GPIO33            |8|   GPIO19 [VSPIMISO]   |  
|              GPIO25            |9|   GPIO18 [VSPI SCK]   |  
|              GPIO26            |10|   GPIO5  [VPSI SS]    |  
|              GPIO27            |11|   GPIO17 [TX2]        |  
|              GPIO14            |12|   GPIO16 [RX2]        |  
|              GPIO12            |13|   GPIO4               |  
|              GND               |14|   GPIO0               |  
|              GPIO13            |15|   GPIO2               |  
|   [FLASH D2] GPIO9             |16|   GPIO15              |  
|   [FLASH D3] GPIO10            |17|   GPIO8 [FLASH D1]    |  
|   [FLASHCMD] GPIO11            |18|   GPIO7 [FLASH D0]    |  
|              VIN 5V            |19|   GPIO6 [FLASHSCK]    |  
|  | USB | | 